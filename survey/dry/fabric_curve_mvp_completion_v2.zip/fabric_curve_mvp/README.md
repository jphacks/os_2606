# 布の乾燥試作 v1（1974年の研究から）

実行：`python model.py --temp 20 --rh 50`。テスト：`python -m unittest -v test_model.py`。Python標準ライブラリのみ。

出典：https://www.jstage.jst.go.jp/article/senshoshi1960/15/2/15_2_59/_pdf
- `published_coefficients.csv`：1974年論文表2の**公表回帰係数**（恒率乾燥期、単位mg/cm²/min）。著者の原測定点ではない。
- `half_times_fig9_APPROX.csv`：1974年論文図9の**一系列の目視概算12点**。系列同定や読取誤差があり、研究者の数値表ではない。
- 10〜30℃, RH10〜70%以外は入力不可。温度・湿度方向とも観測点間は線形補間。独立した実測に対する精度評価は未実施。

出力：恒率期の面積当たり水分蒸発速度、減率期の過剰水分半減時間、減率期開始から「過剰水分が50/20/10%まで減る時間」。後者は図9の概算半減時間を指数減衰とみなした**条件付き計算**。衣服が乾燥完了する時間とは異なる。

未実装（推定できない）：恒率→減率切替時の含水量、衣服の初期含水量・実効面積、衣服素材ごとの減率係数、乾燥完了定義、エアコン設定温度と室内温湿度の関係、P50/P90/P95。

1985年山田論文（https://doi.org/10.2115/fiber.41.6_T248）は5気象条件・18布種の測定を扱うが、今回本文図表の数値取得ができなかったため学習に混入していない。

## NEW: completion-time empirical baseline

`python model.py --temp 19 --rh 48 --predict-completion`

This fits least squares to 10 numerical conditions from Sato et al. (2024), 5 paired cases, **2.01 kg/30-item mixed laundry**. Inputs are **average temperature and humidity throughout the full drying run**, not initial readings. Other clothing types (such as T-shirt alone, towel, hoodie) are not supported, because the existing available cross-study observations do not isolate clothing effects. The 1974 constant-rate experiment is **not combined** with completion labels as if equivalent observations. The model is descriptive, not actionable control or live forecast. P50/P90/P95 and AC mode/setpoint remain unsupported.

`python model.py --temp 19 --rh 48 --predict-completion --clothing hoodie` correctly refuses to make up a hoodie factor.

`python -m unittest -v` runs the tests. Requires `numpy` for the completion option.
